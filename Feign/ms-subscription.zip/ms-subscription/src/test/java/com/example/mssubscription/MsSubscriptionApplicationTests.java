package com.example.mssubscription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSubscriptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
